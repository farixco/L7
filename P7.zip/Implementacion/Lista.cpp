#include "Lista.h"
#include <iostream>
using std::cout, std::endl;

void Lista::Add(char n) {
    // 1. Crear nodo
    Nodo * new_nodo = new Nodo();
    new_nodo->Valor = n;
    // 2. Validar si la lista esta vacia
    if (this->Size == 0){
        this->Head = new_nodo;
        this->Tail = new_nodo;
    } else {
        this->Tail->Next = new_nodo;
        this->Tail = new_nodo;
    }
    // incrementar size
    this->Size += 1;
}

void Lista::Print() {
    Nodo * actual = Head;
    while(actual != NULL){
        std::cout << actual->Valor << std::endl;
        actual = actual->Next;
    }
}


char Lista::Element_At(int index) {
    if (index >= this->Size || index < 0) return -1;

    Nodo * actual = Head;
    while(index > 0){
        actual = actual->Next;
        index--;
    }

    return actual->Valor;
}

void Lista::Remove(char n) {
    Nodo * actual = Head;
    Nodo * anterior = nullptr;
    while (actual != nullptr){
        if (actual->Valor == n){
            // procedemos a eliminar
            if (actual == Head){
                Head = actual->Next;
            }
            else if (actual == Tail){
                Tail = anterior;
            }
            else {
                anterior->Next = actual->Next;
            }

            // Reducimos Size
            this->Size--;

            // Borrar de memoria los objetos
            Nodo * borrar = actual;
            actual = actual->Next; // solo cambia actual, ya que anterior sigue siendo igual
            delete borrar;

        } else {
            //continuar
            anterior = actual;
            actual = actual->Next;
        }

    }
}

int Lista::Search(char n) {
    Nodo * actual = Head;
    int i = 0;
    while (actual != nullptr){
        if (actual->Valor == n) return i;
        i++;
        actual = actual->Next;
    }
    return -1; // valor no encontrado
}

void Lista::Delete_At(int index) {
    if (index >= this->Size || index < 0) return;

    // borrar head?
    if (index == 0){
        Nodo * aBorrar = Head;
        Head = Head->Next;
        Size--;
        delete aBorrar;
        return;
    }

    Nodo * actual = Head->Next;
    Nodo * anterior = Head;
    while(index > 1) {
        anterior = actual;
        actual = actual->Next;
        index--;
    }

    Nodo * aBorrar = actual;
    anterior->Next = actual->Next;
    Size--;
    delete aBorrar;

    if (index == Size -1) // tail?
    {
        Tail = anterior;
    }
}

// Al utilizar este metodo, los datos insertados se haran en orden ascedente.
// Verifique la tabla ASCII para conocer el orden de los datos.
void Lista::AddSorted(char n) {
   Nodo* travel = Head;
   Nodo* nuevo = new Nodo;
   nuevo->Valor = n;
   if (travel->Valor >= nuevo->Valor) {
      nuevo->Next = Head;
      Head = nuevo;
   } else {
      for (int i = 0; i < Size; ++i) {
	 if (travel->Next->Valor >= nuevo->Valor) {
	    nuevo->Next = travel->Next;
	    travel->Next = nuevo;
	    break;
	 } else {
	    travel = travel->Next;
	 }
      }
   }
   nuevo->Next = nullptr;
   Tail->Next = nuevo;
}

// Este metodo imprime la lista de datos de forma recursiva
// en el orden en que se ingresaron (desde el HEAD hasta TAIL)
void Lista::PrintRecursive(int ndx, Nodo* travel) {
   if (ndx == 0) {
      travel = Head;
      cout << travel->Valor << " " << endl;
      return PrintRecursive(ndx + 1, travel);
   } else if (ndx > 0 && ndx < Size) {
      travel = travel->Next;
      cout << travel->Valor << " " << endl;
      return PrintRecursive(ndx + 1, travel);
   }
}

// Este metodo imprie la lista de datos
// en el orden inverso al que se ingresaron (desde TAIL hasta HEAD)
void Lista::PrintInverse() {
   for (int i = Size - 1; i >= 0; --i) {
      Nodo* travel = Head;
      for (int j = 0; j < i; ++j) {
	 travel = travel->Next;
      }
      cout << travel->Valor << " " << endl;
   }
}
