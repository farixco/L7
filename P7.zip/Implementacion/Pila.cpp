//
// Created by Abraham on 14/10/2023.
//

#include "Pila.h"

int Pila::Size() {
    return this->datos->Size;
}

void Pila::Push(char n) {
    this->datos->Add(n);
}

char Pila::Pop() {
    char peek = datos->Element_At(datos->Size-1);
    datos->Delete_At(datos->Size -1);
    return peek;
}

char Pila::Peek() {
    return datos->Element_At(datos->Size-1);
}

// Este metodo inverte el orden de todos los datos en la pila
void Pila::Invert() {
   Pila* pilaTmp = new Pila;
   int size = this->Size();
   for (int i = 0; i < size; ++i) {
      pilaTmp->Push(this->Pop());
   }
   for (int i = 0; i < size; ++i) {
      this->Push(pilaTmp->Pop());
   }
   delete pilaTmp;
}
