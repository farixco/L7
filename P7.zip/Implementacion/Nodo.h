#pragma once
class Nodo {
public:
    char Valor;
    Nodo * Next;
    Nodo () {
        Valor = 0;
        Next  = nullptr;
    }
};


